package ServiceLayer;

import Model.RepositoryPojo;
import Reader.JsonReader;
import UtilsLayer.UtilsClass;


public class RepositoryService {
	
	public static RepositoryPojo pojo;
	public static String getRequestBody(String nodeName)
	{
		 pojo= JsonReader.readJsonTestData("repository", nodeName,RepositoryPojo.class );
		return UtilsClass.pojoToJsonOfString(pojo);
	}

}
