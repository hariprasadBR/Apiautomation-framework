package Reader;


import java.io.FileReader;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;



public class JsonReader {
	
	final static String Path=System.getProperty("user.dir")+("\\src\\test\\resources\\RequestTestDataPayload\\");
	
	public static <T> T readJsonTestData(String fileName,String nodeName,Class<T> pojaClassName)
	{
		try {
			FileReader file = new FileReader(Path+fileName+".json");
			ObjectMapper mapper = new ObjectMapper();
		JsonNode jsonNode= 	mapper.readTree(file);
		return  mapper.treeToValue(jsonNode.get(nodeName), pojaClassName);
			
			
			
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		return null;
	}

}
