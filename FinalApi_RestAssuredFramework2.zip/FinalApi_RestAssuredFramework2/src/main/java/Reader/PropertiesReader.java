package Reader;

import java.io.FileInputStream;

import java.util.Properties;

public class PropertiesReader {
	 static String path;
	public static String getProperty(String KeyName)
	{
	
	path = System.getProperty("user.dir")+("\\src\\main\\resources\\ConfigLayer\\config.properties");
	
	
	try {
		FileInputStream fis = new FileInputStream(path);
		Properties prop = new Properties();
		prop.load(fis);
		return prop.getProperty(KeyName);
		
	} catch (Exception e) {
	
		e.printStackTrace();
	}

	return null;
	
	}
	
	
}
