package BaseAPI;

import Reader.PropertiesReader;
import io.restassured.RestAssured;
import io.restassured.specification.RequestSpecification;

public class BaseApiClass {

	public static RequestSpecification setUp()
	{
		RestAssured.baseURI=PropertiesReader.getProperty("baseURI");
		return RestAssured.given().log().all();
	}
}
