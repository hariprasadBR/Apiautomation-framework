package Model;

import lombok.Data;

@Data
public class RepositoryPojo {

	private String name;
	private String description;
	private String homepage;
	private boolean has_issues;
	private boolean has_projects;
	private boolean has_wiki;
	
	
}



