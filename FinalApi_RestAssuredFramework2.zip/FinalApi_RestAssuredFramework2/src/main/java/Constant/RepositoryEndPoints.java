package Constant;

import Reader.PropertiesReader;

public interface RepositoryEndPoints {

	final static String POSTEndPoints="/user/repos";
	final static String GETEndPoints="/repos/"+PropertiesReader.getProperty("username")+"/";
	final static String PATCHEndPints ="/repos/"+PropertiesReader.getProperty("username")+"/";
	final static String DELETEEndPoints="/repos/"+PropertiesReader.getProperty("username")+"/";
	
	
	
}
