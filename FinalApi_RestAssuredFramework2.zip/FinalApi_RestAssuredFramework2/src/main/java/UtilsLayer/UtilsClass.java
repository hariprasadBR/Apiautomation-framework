package UtilsLayer;

import java.util.HashMap;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class UtilsClass {
	public static String  pojoToJsonOfString(Object object)
	{
		ObjectMapper mapper = new ObjectMapper();
		try {
			return mapper.writeValueAsString(object);
		} catch (JsonProcessingException e) {
			
			e.printStackTrace();
	
		}
		return null;
	}
	

	public static HashMap<String,String> getHeader()
	{
		HashMap<String,String> header = new HashMap<String,String>();
		header.put("Content-Type","application/json");
		
		return header;
	}
	
	
}
