package StepApiDefinition;


import java.io.FileReader;

import org.hamcrest.Matchers;



import BaseAPI.BaseApiClass;
import Constant.RepositoryEndPoints;
import ServiceLayer.RepositoryService;
import UtilsLayer.UtilsClass;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;

public class RepositoryStepApi extends BaseApiClass{
	private static RequestSpecification httpRequest;
	private static 	Response response;
	private static String repoName;
	private static ValidatableResponse validatableResponse;
	

	@Given("user get RequestSpecification Object")
	public void user_get_request_specification_object() {
		 httpRequest = BaseApiClass.setUp();
	   
	}
	
	@When("user add Oauth2 Autorization")
	public void user_add_oauth2_autorization() {
		httpRequest.auth().preemptive().oauth2("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");
	    
	}
	
	//@When("user add request cookies")
	//public void user_add_request_cookies() {
		//httpRequest.cookie("");
	   
	//}
	
	@When("user add request headers")
	public void user_add_request_headers() {
		httpRequest.headers(UtilsClass.getHeader());
	   
	}
	
	@When("user attch requestBody by passing {string} nodeName")
	public void user_attch_request_body_by_passing_node_name(String nodeName) {
		
		httpRequest.body(RepositoryService.getRequestBody(nodeName));
		
		
	    
	}
	
	@When("user select HTTP {string} request")
	public void user_select_http_request(String requestType) {
		
		if(requestType.equalsIgnoreCase("POST"))
		{
			response =httpRequest.post(RepositoryEndPoints.POSTEndPoints);
		}
		else if (requestType.equalsIgnoreCase("GET"))
		{
			response =httpRequest.get(RepositoryEndPoints.GETEndPoints+repoName);
		}
		else if (requestType.equalsIgnoreCase("PATCH"))
		{
			response =httpRequest.patch(RepositoryEndPoints.PATCHEndPints+repoName);
		}
		else if (requestType.equalsIgnoreCase("DELETE"))
		{
			response =httpRequest.delete(RepositoryEndPoints.DELETEEndPoints+repoName);
		}
		
		
		
	   
	}
	
	@Then("user capture repository name")
	public void user_capture_repository_name() {
		 repoName =response.getBody().jsonPath().getString("name");
	   
	}

	@Then("user validate statusCode as {int} and statusLine as {string}")
	public void user_validate_status_code_as_and_status_line_as(Integer code, String line) {
		
		 validatableResponse = response.then().assertThat().statusCode(code)
		.and().statusLine(Matchers.containsString(line));
	    
	}

	@Then("user validate responseTime lessThan {int} ms")
	public void user_validate_response_time_less_than_ms(Integer respTime) {
	   validatableResponse.time(Matchers.lessThan((long)respTime));
	}

	@Then("user validate {string} and {string} key")
	public void user_validate_and_key(String nameKey, String descriptionKey) {
		validatableResponse.body("",Matchers.hasKey(nameKey))
		.and().body("", Matchers.hasKey(descriptionKey));
	    
	}

	@Then("user validate name and description values")
	public void user_validate_name_and_description_values() {
		validatableResponse.body("name",Matchers.equalTo(RepositoryService.pojo.getName()))
		.and().body("description",Matchers.equalTo(RepositoryService.pojo.getDescription()));
	    
	}

	@Then("user validate jsonSchema")
	public void user_validate_json_schema() throws Exception {
		FileReader file = new FileReader(System.getProperty("user.dir")+("\\src\\test\\resources\\JsonSchema\\RepositroryJsonSchema.json"));
		validatableResponse.body(JsonSchemaValidator.matchesJsonSchema(file));
		
	    
	}

	@Then("user generate response logs")
	public void user_generate_response_logs() {
		validatableResponse.log().all();
	   
	}

	
	
}
